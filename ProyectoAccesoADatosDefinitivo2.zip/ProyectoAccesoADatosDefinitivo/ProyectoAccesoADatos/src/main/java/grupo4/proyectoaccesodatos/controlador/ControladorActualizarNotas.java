/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.controlador;

/**
 *
 * @author Diurno
 */
import grupo4.proyectoaccesodatos.modelo.Conexion;
import grupo4.proyectoaccesodatos.modelo.ConsultasProfesor.ConsultasUpdate.ConsultasActualizarNotas;
import grupo4.proyectoaccesodatos.vista.InterfazesProfesor.InterfazesUpdate.InterfazUpdate;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 * Controlador encargado de gestionar la actualización de notas en la interfaz,
 * comunicándose con el modelo y la vista correspondientes.
 */
public class ControladorActualizarNotas {
    /**
     * Referencia a la interfaz gráfica donde se muestran los datos y controles.
     */
    private InterfazUpdate vista;
    /**
     * Modelo encargado de realizar las operaciones de actualización en la base de datos.
     */
    private ConsultasActualizarNotas modelo;
    /**
     * Correo electrónico del profesor, utilizado para filtrar sus asignaturas.
     */
    private String email;
/**
     * Constructor del controlador. Inicializa la vista, el modelo y carga las asignaturas
     * asociadas al profesor. También configura los eventos de la interfaz.
     *
     * @param vista Interfaz gráfica utilizada para actualizar notas.
     * @param email Correo del profesor para cargar solo sus asignaturas.
     */
    public ControladorActualizarNotas(InterfazUpdate vista, String email) {
        this.vista = vista;
        this.modelo = new ConsultasActualizarNotas();
        this.email = email;

        cargarAsignaturas();
        initController();
    }
/**
     * Inicializa los controladores de eventos de la vista, asociando acciones
     * a los componentes interactivos.
     */
    private void initController() {
        vista.btnActualizar.addActionListener(e -> actualizarNota());
    }
/**
     * Obtiene los datos introducidos por el usuario en la interfaz y solicita
     * al modelo la actualización de la nota correspondiente. Muestra mensajes
     * informativos según el resultado de la operación.
     */
    private void actualizarNota() {
        try {
            int idNota = Integer.parseInt(vista.txtIdNota.getText());
            int idAsignatura = (int) vista.cmbAsignaturas.getSelectedItem();
            double nuevaPuntuacion = Double.parseDouble(vista.txtPuntuacion.getText());

            boolean ok = modelo.actualizarNota(idNota, idAsignatura, nuevaPuntuacion);

            if (ok) {
                JOptionPane.showMessageDialog(vista, "Nota actualizada correctamente.");
            } else {
                JOptionPane.showMessageDialog(vista, "Error al actualizar la nota.");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "Valores inválidos: " + ex.getMessage());
        }
    }
    /**
     * Carga en el combo de asignaturas todas aquellas que pertenecen al profesor
     * cuyo correo electrónico fue proporcionado. Realiza una consulta a la base
     * de datos para obtener los IDs de las asignaturas.
     */
    private void cargarAsignaturas() {
        try {
            Connection con = Conexion.getConexion();
            String sql = "SELECT a.id FROM asignaturas a JOIN users u ON a.id_user_profesor = u.id WHERE email = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                vista.cmbAsignaturas.addItem(rs.getInt("id"));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error al cargar asignaturas: " + e.getMessage());
        }
    }
}