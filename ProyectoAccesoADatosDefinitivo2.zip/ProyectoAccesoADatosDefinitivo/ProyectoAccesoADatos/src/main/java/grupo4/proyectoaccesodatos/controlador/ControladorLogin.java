/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.controlador;

import grupo4.proyectoaccesodatos.modelo.Usuario;
import grupo4.proyectoaccesodatos.vista.InterfazesAlumno.InterfazAlumno;
import grupo4.proyectoaccesodatos.vista.InterfazesProfesor.InterfazProfesor;
import grupo4.proyectoaccesodatos.vista.LoginForm;

import javax.swing.*;
/**
 * Controlador encargado de gestionar el proceso de inicio de sesión
 * conectando la vista de login con la lógica de validación del usuario.
 */
public class ControladorLogin {

   /**
     * Vista del formulario de inicio de sesión.
     */
    private final LoginForm vista;

    /**
     * Objeto Usuario utilizado para validar las credenciales introducidas.
     */
    private final Usuario user;

    /**
     * Constructor del controlador. Inicializa la vista y el modelo (Usuario)
     * y configura los eventos del formulario de inicio de sesión.
     *
     * @param vista Vista del formulario de login.
     */

    public ControladorLogin(LoginForm vista) {
        this.vista = vista;
        user = new Usuario();
        initController();
    }
    /**
     * Configura los controladores de eventos para los componentes de la vista,
     * como el botón de inicio de sesión.
     */
    private void initController() {
        vista.getBtnLogin().addActionListener(e -> login());
    }
    /**
     * Realiza el proceso de inicio de sesión obteniendo las credenciales desde la vista,
     * validando al usuario mediante el modelo y abriendo la interfaz correspondiente
     * en función del rol del usuario (profesor o alumno). También muestra mensajes
     * de error si las credenciales no son válidas.
     */
    private void login() {
        String email = vista.getTxtEmail().getText();
        String pass = String.valueOf(vista.getTxtPassword().getPassword());

        user.validarLogin(email, pass);

        if (user.getId() != 0) {
            JOptionPane.showMessageDialog(vista,
                    "Bienvenido " + user.getNombre() + " (" + (user.getRol() == 'p' ? "Profesor" : "Alumno") + ")");
            if (user.getRol() == 'p') {
                InterfazProfesor interfazPrincipal = new InterfazProfesor(user.getEmail());
                interfazPrincipal.setVisible(true);
            } else if (user.getRol() == 'a') {
                InterfazAlumno interfazAlumno = new InterfazAlumno(user.getEmail());
                interfazAlumno.setVisible(true);
            }

        } else {
            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
