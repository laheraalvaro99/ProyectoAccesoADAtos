/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.controlador;

import grupo4.proyectoaccesodatos.vista.LoginForm;
/**
 * Clase principal de la aplicación. Se encarga de iniciar la interfaz de login
 * y asociarle su controlador correspondiente.
 */
public class Main {
    /**
     * Método de entrada de la aplicación. Crea la vista del formulario de login,
     * inicializa su controlador y muestra la interfaz al usuario.
     *
     * @param args Argumentos de la línea de comandos (no utilizados).
     */
    public static void main(String[] args) {
        LoginForm vista = new LoginForm();
        new ControladorLogin(vista);
        vista.setVisible(true);
    }
}