/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Clase encargada de gestionar la conexión a la base de datos SQL Server.
 * Implementa un patrón singleton para reutilizar una única conexión durante
 * toda la ejecución de la aplicación.
 */
public class Conexion {
   /**
     * Instancia única de la conexión a la base de datos.
     */
    private static Connection conexion;

    /**
     * Devuelve la conexión a la base de datos. Si la conexión aún no ha sido
     * establecida, se crea una nueva utilizando el driver de SQL Server.
     *
     * @return Objeto Connection representando la conexión a la base de datos.
     */

    public static Connection getConexion() {
        if (conexion == null) {
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url = "jdbc:sqlserver://localhost:1433;"
                        + "databaseName=academia;"
                        + "integratedSecurity=true;"
                        + "encrypt=false;"
                        + "trustServerCertificate=true;";
                conexion = DriverManager.getConnection(url);
                System.out.println("Conexión establecida correctamente.");
            } catch (SQLException e) {
                System.out.println("Error al conectar: " + e.getMessage());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return conexion;
    }
}