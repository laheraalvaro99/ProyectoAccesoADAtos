/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.modelo.ConsultasProfesor.ConsultasEliminar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


/**
 * Clase encargada de eliminar asignaturas de la base de datos.
 * Permite eliminar una asignatura por su nombre y mostrar mensajes
 * de confirmación o error en la interfaz gráfica.
 */
public class ConsultaEliminarAsignatura {

    /**
     * Elimina una asignatura de la base de datos por su nombre.
     *
     * @param nombreAsignatura Nombre de la asignatura que se desea eliminar.
     * @param ventana JFrame desde el cual se muestra el mensaje y se cierra tras la eliminación.
     * @return true si la asignatura se eliminó correctamente, false en caso contrario.
     */
    public boolean eliminarAsignaturaPorNombre(String nombreAsignatura, JFrame ventana) {
        boolean eliminado = false;

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://localhost:1433;"
                    + "databaseName=Academia;"
                    + "integratedSecurity=true;"
                    + "encrypt=false;"
                    + "trustServerCertificate=true;";

            Connection conexion = DriverManager.getConnection(url);

            
            String sql = "DELETE FROM asignaturas WHERE nombre = ?";
            PreparedStatement stmt = conexion.prepareStatement(sql);
            stmt.setString(1, nombreAsignatura);

            
            int filasAfectadas = stmt.executeUpdate();

            if (filasAfectadas > 0) {
                eliminado = true; 
                
                JOptionPane.showMessageDialog(ventana, "Asignatura eliminada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

                ventana.dispose();
            } else {

                JOptionPane.showMessageDialog(ventana, "No se encontró la asignatura para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            stmt.close();
            conexion.close();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }

        return eliminado;
    }
}
