/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.modelo.ConsultasProfesor.ConsultasEliminar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Clase encargada de gestionar la eliminación de notas en la base de datos.
 * Permite obtener el ID de un usuario por email, consultar notas de un profesor
 * y eliminar notas, incluyendo sus referencias en la tabla historico_notas.
 */
public class ConsultaEliminarNota {

    /** Conexión a la base de datos. */
    private Connection conexion;

    /**
     * Constructor de la clase. Establece la conexión con la base de datos SQL Server.
     */
    public ConsultaEliminarNota() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://localhost:1433;"
                    + "databaseName=Academia;"
                    + "integratedSecurity=true;"
                    + "encrypt=false;"
                    + "trustServerCertificate=true;";

             conexion = DriverManager.getConnection(url);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
           Logger.getLogger(ConsultaEliminarNota.class.getName()).log(Level.SEVERE, null, ex);
       }
        
        
    }
    /**
     * Obtiene el ID de un usuario a partir de su correo electrónico.
     *
     * @param email Correo electrónico del usuario.
     * @return ID del usuario si se encuentra, -1 en caso contrario.
     */
     public int obtenerIdUsuarioPorEmail(String email) {
        String query = "SELECT users.id FROM users WHERE users.email = ?";
        int usuarioId = -1;

        try (PreparedStatement stmt = conexion.prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                usuarioId = rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return usuarioId;
    }
     /**
     * Obtiene todas las notas asociadas a un profesor específico.
     *
     * @param profesorId ID del profesor cuyas notas se quieren consultar.
     * @return Arreglo bidimensional de objetos donde cada fila contiene:
     *         [0] = ID de la nota,
     *         [1] = nombre del alumno,
     *         [2] = apellido del alumno,
     *         [3] = nombre de la asignatura,
     *         [4] = puntuación de la nota.
     */
     public Object[][] obtenerNotasPorProfesor(int profesorId) {
    String query = "SELECT notas.id AS nota_id, users.nombre AS alumno_nombre, users.apellido AS alumno_apellido, " +
                   "asignaturas.nombre AS asignatura, notas.puntuacion " +
                   "FROM notas " +
                   "JOIN asignaturas ON notas.id_asignatura = asignaturas.id " +
                   "JOIN users ON notas.id_user_alumno = users.id " +
                   "WHERE notas.id_user_profesor = ?";

    List<Object[]> resultados = new ArrayList<>();

    try (PreparedStatement stmt = conexion.prepareStatement(query)) {
        stmt.setInt(1, profesorId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Object[] fila = new Object[5];  
            fila[0] = rs.getInt("nota_id");  
            fila[1] = rs.getString("alumno_nombre");
            fila[2] = rs.getString("alumno_apellido");
            fila[3] = rs.getString("asignatura");
            fila[4] = rs.getString("puntuacion");
            resultados.add(fila);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return resultados.toArray(new Object[0][0]);
}
      /**
     * Elimina una nota de la base de datos y sus referencias en la tabla historico_notas.
     *
     * @param idNota ID de la nota que se desea eliminar.
     * @return true si la nota se eliminó correctamente, false en caso contrario.
     */
      public boolean eliminarNota(int idNota) {
    String queryHistorico = "DELETE FROM historico_notas WHERE id_notas = ?";

    try (PreparedStatement stmtHistorico = conexion.prepareStatement(queryHistorico)) {
        stmtHistorico.setInt(1, idNota);
        
        int filasEliminadasHistorico = stmtHistorico.executeUpdate();
        
        if (filasEliminadasHistorico > 0) {
            String queryNotas = "DELETE FROM notas WHERE id = ?";
            
            try (PreparedStatement stmtNotas = conexion.prepareStatement(queryNotas)) {
                stmtNotas.setInt(1, idNota);
                int filasEliminadasNotas = stmtNotas.executeUpdate();

                return filasEliminadasNotas > 0;
            }
        } else {
            return false;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false; 
    }
}

}
