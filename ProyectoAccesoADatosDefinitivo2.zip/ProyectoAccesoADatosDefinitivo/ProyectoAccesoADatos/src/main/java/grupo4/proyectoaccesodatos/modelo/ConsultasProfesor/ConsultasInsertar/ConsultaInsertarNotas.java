/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.modelo.ConsultasProfesor.ConsultasInsertar;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 * Clase encargada de insertar notas en la base de datos.
 * Proporciona métodos para obtener los IDs de usuarios y asignaturas
 * y realizar la inserción de notas de manera segura.
 */
public class ConsultaInsertarNotas {

    /**
     * Inserta una nota en la base de datos para un alumno y asignatura específicos,
     * registrada por un profesor identificado por su email.
     *
     * @param nombreA Nombre del alumno.
     * @param apellidoA Apellido del alumno.
     * @param nAsignatura Nombre de la asignatura.
     * @param email Email del profesor que registra la nota.
     * @param nota Puntuación de la nota a insertar.
     */
     public void insertarNotas(String nombreA, String apellidoA, String nAsignatura, String email, double nota) {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            String url = "jdbc:sqlserver://localhost:1433;"
                         + "databaseName=Academia;"
                         + "integratedSecurity=true;"
                         + "encrypt=false;"
                         + "trustServerCertificate=true;";


            int codAlumno = codigoUsr(nombreA, apellidoA);
            int codProfesor = codigoUsrPorEmail(email);
            int asignatura = codigoAsignatura(nAsignatura);


            if (asignatura == 0) {
                JOptionPane.showMessageDialog(null, "No se pudo encontrar la asignatura en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;  
            }


            LocalDateTime fechaHoraActual = LocalDateTime.now();
            Timestamp fecha = Timestamp.valueOf(fechaHoraActual);

            try (Connection conexion = DriverManager.getConnection(url);
                 PreparedStatement pstmt = conexion.prepareStatement(
                     "INSERT INTO notas (id_user_alumno, id_user_profesor, id_asignatura, puntuacion, fecha_registro) VALUES (?, ?, ?, ?, ?)"
                 )) {


                pstmt.setInt(1, codAlumno);
                pstmt.setInt(2, codProfesor);
                pstmt.setInt(3, asignatura);
                pstmt.setDouble(4, nota);
                pstmt.setTimestamp(5, fecha);

                int filasAfectadas = pstmt.executeUpdate();


                if (filasAfectadas > 0) {
                    JOptionPane.showMessageDialog(null, "Nota insertada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo insertar la nota", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error en la inserción: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConsultaInsertarNotas.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Error al cargar el controlador de la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
      /**
     * Obtiene el ID de un usuario a partir de su email.
     *
     * @param email Email del usuario.
     * @return ID del usuario si se encuentra, 0 en caso contrario.
     */
    public static int codigoUsrPorEmail(String email) {
    int idUsuario = 0;

    try {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://localhost:1433;"
                + "databaseName=Academia;"
                + "integratedSecurity=true;"
                + "encrypt=false;"
                + "trustServerCertificate=true;";


        try (Connection conexion = DriverManager.getConnection(url);
             PreparedStatement pstmt = conexion.prepareStatement(
                     "SELECT id FROM users WHERE email = ?")) {

            pstmt.setString(1, email);
            ResultSet resul = pstmt.executeQuery();

            if (resul.next()) {
                idUsuario = resul.getInt("id");
            } else {
                System.out.println("Usuario no encontrado con el email: " + email);
            }

            resul.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    } catch (ClassNotFoundException ex) {
        Logger.getLogger(ConsultaInsertarNotas.class.getName()).log(Level.SEVERE, null, ex);
    }

    return idUsuario;
}
  /**
     * Obtiene el ID de un usuario a partir de su nombre y apellido.
     *
     * @param nombre Nombre del usuario.
     * @param apellido Apellido del usuario.
     * @return ID del usuario si se encuentra, 0 en caso contrario.
     */
    public static int codigoUsr(String nombre, String apellido) {
        int datos = 0;

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://localhost:1433;"
                    + "databaseName=Academia;"
                    + "integratedSecurity=true;"
                    + "encrypt=false;"
                    + "trustServerCertificate=true;";

            
            try (Connection conexion = DriverManager.getConnection(url);
                 PreparedStatement pstmt = conexion.prepareStatement("SELECT id FROM users WHERE nombre = ? AND apellido = ?")) {

               
                pstmt.setString(1, nombre);
                pstmt.setString(2, apellido);

                ResultSet resul = pstmt.executeQuery();

                if (resul.next()) {
                    datos = resul.getInt("id");
                } else {
                    System.out.println("Usuario no encontrado.");
                }

                resul.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConsultaInsertarNotas.class.getName()).log(Level.SEVERE, null, ex);
        }

        return datos;
    }

    /**
     * Obtiene el ID de una asignatura a partir de su nombre.
     *
     * @param nombre Nombre de la asignatura.
     * @return ID de la asignatura si se encuentra, 0 en caso contrario.
     */
    public static int codigoAsignatura(String nombre) {
        int datos = 0;

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://localhost:1433;"
                    + "databaseName=Academia;"
                    + "integratedSecurity=true;"
                    + "encrypt=false;"
                    + "trustServerCertificate=true;";

            
            try (Connection conexion = DriverManager.getConnection(url);
                 PreparedStatement pstmt = conexion.prepareStatement("SELECT id FROM asignaturas WHERE nombre = ?")) {

                
                pstmt.setString(1, nombre);

                ResultSet resul = pstmt.executeQuery();

                if (resul.next()) {
                    datos = resul.getInt("id");
                } else {
                    System.out.println("Asignatura no encontrada.");
                }

                resul.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConsultaInsertarNotas.class.getName()).log(Level.SEVERE, null, ex);
        }

        return datos;
    }
}
