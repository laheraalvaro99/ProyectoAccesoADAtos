/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.modelo.ConsultasProfesor.ConsultasInsertar;

import grupo4.proyectoaccesodatos.modelo.Consultas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


/**
 * Clase encargada de insertar usuarios en la base de datos.
 * Permite crear nuevos usuarios con nombre, apellido, email, contraseña y rol.
 */
public class ConsultaInsertarUsuario {

    /**
     * Inserta un nuevo usuario en la base de datos.
     *
     * @param nombre Nombre del usuario.
     * @param apellido Apellido del usuario.
     * @param rol Rol del usuario ('a' = alumno, 'p' = profesor).
     * @param email Correo electrónico del usuario.
     * @param contraseña Contraseña del usuario.
     */
   public void insertarUsuario(String nombre, String apellido, String rol,String email,String contraseña) {
        try {
            
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            
            String url = "jdbc:sqlserver://localhost:1433;"
                         + "databaseName=Academia;"
                         + "integratedSecurity=true;"
                         + "encrypt=false;"
                         + "trustServerCertificate=true;";

            try (Connection conexion = DriverManager.getConnection(url);
                 PreparedStatement pstmt = conexion.prepareStatement(
                     "INSERT INTO users (nombre, apellido,email,password,rol) VALUES (?, ?, ?,?,?)"
                 )) {

                
                pstmt.setString(1, nombre);
                pstmt.setString(2, apellido);
                pstmt.setString(3, email);
                pstmt.setString(4, contraseña);
                pstmt.setString(5, rol);

                
                int filasAfectadas = pstmt.executeUpdate();

                
                if (filasAfectadas > 0) {
                    JOptionPane.showMessageDialog(null, "Usuario insertado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo insertar el usuario", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error en la inserción: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Error al cargar el controlador de la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
