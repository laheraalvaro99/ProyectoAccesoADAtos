/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.modelo.ConsultasProfesor.ConsultasInsertar;


import grupo4.proyectoaccesodatos.modelo.Consultas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


/**
 * Clase encargada de insertar asignaturas en la base de datos.
 * Proporciona métodos para obtener IDs de usuarios, buscar profesores
 * y reemplazar vocales en cadenas de texto.
 */
public class ConsultasInsertarAsignatura {

    /**
     * Inserta una asignatura en la base de datos asignándola a un profesor.
     *
     * @param usuario Email del profesor que imparte la asignatura.
     * @param nAsignatura Nombre de la asignatura.
     * @param nCurso Nombre del curso de la asignatura.
     */

    public void insertarAsignatura(String usuario, String nAsignatura, String nCurso) {
    try {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://localhost:1433;"
                    + "databaseName=Academia;"
                    + "integratedSecurity=true;"
                    + "encrypt=false;"
                    + "trustServerCertificate=true;";

        try (Connection conexion = DriverManager.getConnection(url);
             PreparedStatement pstmt = conexion.prepareStatement(
                 "INSERT INTO asignaturas (nombre, curso, id_user_profesor) VALUES (?, ?, ?)")) {

            
            pstmt.setString(1, nAsignatura);
            pstmt.setString(2, nCurso+"º");  
            pstmt.setInt(3, codigoUsrPorEmail(usuario));  

            
            int filasAfectadas = pstmt.executeUpdate();
            
            
            if (filasAfectadas > 0) {
                
                JOptionPane.showMessageDialog(null, "Asignatura insertada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                
                JOptionPane.showMessageDialog(null, "No se pudo insertar la asignatura", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error en la inserción: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    } catch (ClassNotFoundException ex) {
        Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, "Error al cargar el controlador de la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    /**
     * Obtiene el ID de un usuario a partir de su email.
     *
     * @param email Email del usuario.
     * @return ID del usuario si se encuentra, 0 en caso contrario.
     */
     public static int codigoUsrPorEmail(String email) {
    int idUsuario = 0;

    try {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://localhost:1433;"
                + "databaseName=Academia;"
                + "integratedSecurity=true;"
                + "encrypt=false;"
                + "trustServerCertificate=true;";

        
        try (Connection conexion = DriverManager.getConnection(url);
             PreparedStatement pstmt = conexion.prepareStatement(
                     "SELECT id FROM users WHERE email = ?")) {

            pstmt.setString(1, email);
            ResultSet resul = pstmt.executeQuery();

            if (resul.next()) {
                idUsuario = resul.getInt("id");
            } else {
                System.out.println("Usuario no encontrado con el email: " + email);
            }

            resul.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    } catch (ClassNotFoundException ex) {
        Logger.getLogger(ConsultaInsertarNotas.class.getName()).log(Level.SEVERE, null, ex);
    }

    return idUsuario;
}

    /**
     * Obtiene el ID de un profesor a partir de su nombre y apellido.
     *
     * @param nombre Nombre del profesor.
     * @param apellido Apellido del profesor.
     * @return ID del profesor si se encuentra, 0 en caso contrario.
     */
   public static int codigoProfesor(String nombre, String apellido) {
    int datos = 0;

    try {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://localhost:1433;"
                    + "databaseName=Academia;"
                    + "integratedSecurity=true;"
                    + "encrypt=false;"
                    + "trustServerCertificate=true;";

        try (Connection conexion = DriverManager.getConnection(url);
             Statement sentencia = conexion.createStatement()) {

           
            String sql = "SELECT id FROM users WHERE nombre='" + nombre + "' AND apellido='" + apellido + "'";
            ResultSet resul = sentencia.executeQuery(sql);

            if (resul.next()) {
                datos = resul.getInt("id");
            } else {
                System.out.println("Profesor no encontrado.");
            }

            resul.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    } catch (ClassNotFoundException ex) {
        Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
    }

    return datos;
}
   /**
     * Reemplaza todas las vocales de un texto por el carácter '%'.
     *
     * @param texto Texto de entrada.
     * @return Cadena con las vocales reemplazadas por '%'.
     */
    public static String reemplazarVocales(String texto) {

        StringBuilder resultado = new StringBuilder();
        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);
            if ("AEIOUaeiou".indexOf(c) != -1) {
                resultado.append('%');
            } else {
                resultado.append(c);
            }
        }
        return resultado.toString();
    }
    
}
