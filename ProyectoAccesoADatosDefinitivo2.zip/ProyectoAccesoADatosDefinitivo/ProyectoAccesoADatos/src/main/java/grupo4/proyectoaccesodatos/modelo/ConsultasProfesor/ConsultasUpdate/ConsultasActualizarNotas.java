/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.modelo.ConsultasProfesor.ConsultasUpdate;

import grupo4.proyectoaccesodatos.modelo.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Clase encargada de actualizar notas en la base de datos.
 * Permite modificar tanto la asignatura como la puntuación de una nota existente.
 */
public class ConsultasActualizarNotas {

    /**
     * Actualiza la asignatura y la puntuación de una nota específica.
     *
     * @param idNota ID de la nota a actualizar.
     * @param idNuevaAsignatura ID de la nueva asignatura a asignar a la nota.
     * @param nuevaPuntuacion Nueva puntuación de la nota.
     * @return true si la actualización fue exitosa, false en caso contrario.
     */

    public boolean actualizarNota(int idNota, int idNuevaAsignatura, double nuevaPuntuacion) {
        boolean actualizado = false;

        try {
            Connection con = Conexion.getConexion();
            String sql = "UPDATE notas SET id_asignatura = ?, puntuacion = ? WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idNuevaAsignatura);
            ps.setDouble(2, nuevaPuntuacion);
            ps.setInt(3, idNota);

            int filas = ps.executeUpdate();
            actualizado = filas > 0;

        } catch (SQLException e) {
            System.out.println("Error al actualizar nota: " + e.getMessage());
        }

        return actualizado;
    }
}