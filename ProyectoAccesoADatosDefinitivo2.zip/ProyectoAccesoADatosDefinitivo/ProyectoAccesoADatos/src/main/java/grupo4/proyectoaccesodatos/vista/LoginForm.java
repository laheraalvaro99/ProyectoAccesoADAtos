/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo4.proyectoaccesodatos.vista;

import javax.swing.*;

/**
 * Clase que representa el formulario de inicio de sesión de la academia.
 * Contiene campos para email y contraseña, y un botón de login.
 */
public class LoginForm extends JFrame {

    private final JTextField txtEmail;
    private final JPasswordField txtPassword;
    private final JButton btnLogin;

    /**
     * Constructor que inicializa la interfaz del formulario de login.
     * Configura la ventana, los campos de texto y el botón de inicio de sesión.
     */
    public LoginForm() {
        setTitle("Login - Academia");
        setSize(320, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(30, 30, 100, 25);
        add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(130, 30, 150, 25);
        add(txtEmail);

        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setBounds(30, 70, 100, 25);
        add(lblPass);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(130, 70, 150, 25);
        add(txtPassword);

        btnLogin = new JButton("Ingresar");
        btnLogin.setBounds(100, 120, 100, 30);
        add(btnLogin);
    }

     /**
     * Obtiene el campo de texto para el email.
     *
     * @return JTextField del email.
     */
    public JTextField getTxtEmail() { return txtEmail; }

    /**
     * Obtiene el campo de texto para la contraseña.
     *
     * @return JPasswordField de la contraseña.
     */
    public JPasswordField getTxtPassword() { return txtPassword; }

    /**
     * Obtiene el botón de inicio de sesión.
     *
     * @return JButton para iniciar sesión.
     */
    public JButton getBtnLogin() { return btnLogin; }
}