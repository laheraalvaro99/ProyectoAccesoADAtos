/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login;

import interfaces.InterfazPrincipal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.*;
import interfaces.*;
import alumno.*;
import java.sql.SQLException;
/**
 *
 * @author Diurno
 */
public class LoginForm extends JFrame {
     private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    
    public LoginForm() {
        setTitle("Login - Academia");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblUser = new JLabel("EMAIL:");
        lblUser.setBounds(30, 30, 100, 25);
        add(lblUser);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(130, 30, 120, 25);
        add(txtUsuario);

        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setBounds(30, 70, 100, 25);
        add(lblPass);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(130, 70, 120, 25);
        add(txtPassword);

        btnLogin = new JButton("Ingresar");
        btnLogin.setBounds(100, 120, 100, 30);
        add(btnLogin);
         btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el texto del campo de usuario
                 String usuario = txtUsuario.getText();

                // Obtener la contraseña (como un arreglo de caracteres, se puede convertir a String si se necesita)
                char[] password = txtPassword.getPassword();
                String contrasena = new String(password);

                // Realizar la validación en la base de datos
                String rol = validarLogin(usuario, contrasena);
                if (rol != null) {
                    // Si el usuario y la contraseña son correctos, abrir la interfaz correspondiente
                    JOptionPane.showMessageDialog(null, "¡Inicio de sesión exitoso!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

                    // Crear la ventana correspondiente y pasarle el usuario (y rol si es necesario)
                    if ("p".equals(rol)) {
                        // Si el rol es 'p', abrir la interfaz del profesor
                        InterfazPrincipal interfazPrincipal = new InterfazPrincipal(usuario);
                        interfazPrincipal.setVisible(true);
                    } else if ("a".equals(rol)) {
                        // Si el rol es 'a', abrir la interfaz del alumno
                        InterfazAlumno interfazAlumno = new InterfazAlumno(usuario);
                        interfazAlumno.setVisible(true);
                    }

                    // Cerrar el formulario de login
                    dispose();
                } else {
                    // Si la validación falla, mostrar un mensaje de error
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
       private String validarLogin(String usuario, String contrasena) {
        String rol = null;

        // Detalles de la conexión a la base de datos
        String url = "jdbc:sqlserver://localhost:1433;"
                + "databaseName=Academia;"
                + "integratedSecurity=true;"
                + "encrypt=false;"
                + "trustServerCertificate=true;";
        
        String consulta = "SELECT rol FROM users WHERE email = ? AND password = ?";

        try (Connection conexion = DriverManager.getConnection(url);
             PreparedStatement ps = conexion.prepareStatement(consulta)) {

            // Asignamos los parámetros al PreparedStatement
            ps.setString(1, usuario);
            ps.setString(2, contrasena);

            // Ejecutar la consulta y obtener los resultados
            ResultSet rs = ps.executeQuery();

            // Si se encuentra un usuario con el nombre y la contraseña, obtener el rol
            if (rs.next()) {
                rol = rs.getString("rol");  // Obtener el rol del usuario
            }

            rs.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al conectarse a la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }

        return rol;
    }
    // Getters
    public JTextField getTxtUsuario() { return txtUsuario; }
    public JPasswordField getTxtPassword() { return txtPassword; }
    public JButton getBtnLogin() { return btnLogin; }
     public static void main(String[] args) {
        // Crear y mostrar el formulario de login
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                LoginForm loginForm = new LoginForm();
                loginForm.setVisible(true); // Muestra la ventana
            }
        });
    }
}
